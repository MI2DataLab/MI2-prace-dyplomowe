### Name: period.loss
### Title: Aggregating losses by period
### Aliases: period.loss


### ** Examples

data(loss.data.object)
x<- read.loss(1,2,loss.data.object)
 t0 <- period.loss(x,"none"); t0
 t1 <- period.loss(x,"days"); t1
 t2 <- period.loss(x,"weeks"); t2
 t3 <- period.loss(x,"months"); t3
 t4 <- period.loss(x,"quarters"); t4

sum(t0);sum(t1); sum(t2); sum(t3); sum(t4) # note that all these values must be equal

# the same with dates - note that only for days and no period there are original
# dates; for weeks, months and periods there are only dates opening period in which
# loss occured

 t0 <- period.loss(x,"none",dts=T); t0
 t1 <- period.loss(x,"days",dts=T); t1
 t2 <- period.loss(x,"weeks",dts=T); t2
 t3 <- period.loss(x,"months",dts=T); t3
 t4 <- period.loss(x,"quarters",dts=T); t4

sum(t0);sum(t1); sum(t2); sum(t3); sum(t4)



