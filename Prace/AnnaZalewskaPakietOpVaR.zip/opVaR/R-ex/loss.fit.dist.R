### Name: loss.fit.dist
### Title: Fits density for loss density
### Aliases: loss.fit.dist


### ** Examples

data(loss.data.object)
x<- read.loss(5,5,loss.data.object)

# first example:

mx<-x[,2]

par(mfrow=c(2,2))
loss.fit.dist("gamma",x)
loss.fit.dist("gamma",mx,col="blue") # no difference between mx and x
loss.fit.dist("gamma",mx,col = "darkgreen",qq=T)

# second example:

par(mfrow=c(2,1))
a = loss.fit.dist("inverse gaussian",col = "blue",x,qq=T)# there are emprical and theoretical quantiles

# third example: 

loss.fit.dist("exponential",x)

#  fourth example:

st<- list(shape=0.7882,scale = 11533) 
par(mfrow=c(2,1))
loss.fit.dist("weibull",x,start = st) # fitting weibull distribution with given start
loss.fit.dist("weibull",x) # and without start

# fifth example:

par(mfrow=c(2,1))
sta<-list(sd = 3,mean = 0.5)
a1 = loss.fit.dist(dnorm,x,start = sta,name = "normal!") # of course "normal" is recognised distribution
# but supplying pars for the normal distribution is not supported!
# so it can be only that way
a2 = loss.fit.dist(dnorm,x,start = sta,name = "normal!",col = "blue")
# method is optim argument
# compare parameters
a1$param
a2$param 

# sixth example:

sta<-list(sd = 3,mean = 0.5)
loss.fit.dist(dnorm,x,start = sta,name = "normal!") 
a = loss.fit.dist(dnorm,x,start = sta,name = "normal!",qq = TRUE);summary(a)
head(cbind(a$q.e,a$q.t))




