### Name: key.sum
### Title: Function summing by a given key
### Aliases: key.sum


### ** Examples

# the first example:

v <- c(0,1,2,3.4,2)
u <- c(2,2,0,1)

key.sum(v,u)

# the second example:

v1 <- c(0,1,2,3.4,2)
u1 <- c(2,2,0)

key.sum(v1,u1) # of course there is not enough u data to have v1[5] accounted in the value vector

# the third example:

v2 <- c(0,1,2,3.4)
u2 <- c(2,2,0,1)

key.sum(v2,u2) # of course there is not enough v2 data to sum by u2




