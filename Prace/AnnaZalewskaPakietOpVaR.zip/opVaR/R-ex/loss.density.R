### Name: loss.density
### Title: Plots loss density
### Aliases: loss.density


### ** Examples

data(loss.data.object)

# first example:
 
 loss.density(1,7,loss.data.object) # loss density from all business lines 
 #(loss.data.object$blines) and risk category Internal Fraud
 
# second example:
 
 loss.density(1,7,loss.data.object,no=T) # second example, but with no empty plots

# third example:

 loss.density(1,1,loss.data.object) # of course it is empty (no loss data)
 # see
 D <- loss.matrix(loss.data.object); par(mfrow = c(1,1))
 loss.matrix.image(D,loss.data.object$blines,loss.data.object$rcateg)

# fourth example:

 loss.density(1,7,loss.data.object,period="quarters") # loss are aggreagated by quarters

# fifth example:

 loss.density(1,7, loss.data.object,bnumb=c(1,2,3,5,6,7)) # in this example business lines are
                                                                        # loss.data.object$blines[c(1,2,3,5,6,7)]

# sixth example:

 loss.density(1,5,loss.data.object,bnumb=c(5)) # risk category is loss.data.object$rlines[5]
   # and because bnumb=c(5), there is only one business line, loss.data.object$blines[5] 

# seventh example:

 loss.density(1,5,loss.data.object,kernel="triangular") 

# eighth example:

 # (with some mistake)
 loss.density(1,5,loss.data.object,bnumb=c(5),rnumb=c(11))
# of course rnumb=c(11) makes no sense, but it does not affect this function, because there is already
# one chosen position from risk categories and it is 5, not 11 so 11 is simply ignored
# (and note that we have no 11th risk category)




