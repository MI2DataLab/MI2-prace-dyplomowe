### Name: print.lf
### Title: Printing for "fl" class
### Aliases: print.lf


### ** Examples

# The function is currently defined as
# function(x){ print(x$param)
# print(x$ad)}



