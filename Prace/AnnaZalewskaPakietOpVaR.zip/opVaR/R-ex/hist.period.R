### Name: hist.period
### Title: Loss frequency histograms
### Aliases: hist.period


### ** Examples

# data comes from risk category called "Execution, Delivery & Process Management"
# and from business line called "Payment & Settlement"

# the first example:

 data(loss.data.object)
 x<- read.loss(5,5,loss.data.object)

 hist.period(x,"weeks")

# the second example:

 data(loss.data.object)
 x<- read.loss(5,5,loss.data.object)
 z<- {}         

 par(mfrow=c(2,2))
 z$days <- hist.period(x,"days",col = "pink1")
 z$weeks <- hist.period(x,"weeks",col = "lightblue")
 z$months <- hist.period(x,"months",col = "khaki1" )
 z$quarters <- hist.period(x,"quarters",col = "lightgreen")

z

# the third example:

 data(loss.data.object)
 x<- read.loss(5,5,loss.data.object)
 y<- {}         

 # begin and end dates would be given:
 par(mfrow=c(2,2))
 y$days <- hist.period(x,"days",col = "pink1",begin="2010-01-01",end="2010-12-31")
 y$weeks <- hist.period(x,"weeks",col = "lightblue",begin="2010-01-01",end="2010-12-31")
 y$months <- hist.period(x,"months",col = "khaki1",begin="2010-01-01",end="2010-12-31")
 y$quarters <- hist.period(x,"quarters",col = "lightgreen",begin="2010-01-01",end="2010-12-31")

y       # compare with z from the previous example




