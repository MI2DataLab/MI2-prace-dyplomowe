### Name: fit.plot
### Title: Plotting fitted and empirical distribution
### Aliases: fit.plot


### ** Examples

# first example:

data(loss.data.object)  # data reading
x<- read.loss(1,2,loss.data.object)     # choice of data
z<- x[,2]       # z is loss data

fit.plot(z,dnorm, param = list(mean = mean(z),sd = sd(z)))

 # and the same with draw.diff = T
fit.plot(z,dnorm, param = list(mean = mean(z),sd = sd(z)),draw.diff=T)

 # draw.diff = T, draw.max = T (maximum difference is drawn), 
 # n = 40 (density values are computed only for 40 points)
fit1<-fit.plot(z,dnorm, param = list(mean = mean(z),sd = sd(z)),draw.diff=T,n=40)
length(fit1$teor) # absolute differences are computed only for positive density arguments
length(fit1$emp)  # number of arguments
# then ad is computed as sum of that absolute differences
# compare:
sum(abs(fit1$teor - fit1$emp))
fit1$ad

 # compare:
par(mfrow = c(2,1))
fit.plot(z,dnorm, param = list(mean = mean(z),sd = sd(z)),draw.diff=T,n=40,col2 = "darkblue")
fit.plot(z,dnorm, param = list(mean = mean(z),sd = sd(z)),draw.diff=T,n=40,positive=F,col2 = "darkblue")
 # more values thanks to positive = F

# second example:

 # beta distribution is special because it is scaled
fit.plot(z,dbeta,"beta", param = list(shape1 = 0.4,shape2=17)) 
 # ... and with x logarithmic scale
fit.plot(z,dbeta,"beta", param = list(shape1 = 0.4,shape2=17),log = "x") 

# third example:

parameters <-loss.fit.dist("lognormal",x)$param # fits lognormal distribution to
                                                                # second column of our data (i.e. z)            
parameters <- as.numeric(parameters)
parameters # the estimated parameters of lognormal distribution

fit.plot(z,dlnorm,distname = "lognormal",
        param = list(meanlog = parameters[1],sdlog = parameters[2]))

 # ... and with x logarithmic scale
fit.plot(z,dlnorm,distname = "lognormal",
        param = list(meanlog = parameters[1],sdlog = parameters[2]),log="x")
 # lognormal seems to fit that data

 # and with differences drawn (there was ylim changed to see these lines better)
fit.plot(z,dlnorm,distname = "lognormal",
 param = list(meanlog = parameters[1],sdlog = parameters[2]),log="x",draw.diff=T,ylim = c(0,4e-05))




