### Name: root.period
### Title: Fitting loss frequency distribution
### Aliases: root.period
### Keywords: ~kwd1 ~kwd2

### ** Examples

data(loss.data.object)
x<- read.loss(5,5,loss.data.object)

# first example:
y<- root.period(x,"days","poisson")
        t <- y$table; t
        par <- y$param; par
        p <- y$p; p

# second example: 

 root.period(x,"days","nbinomial") # rather good fit
 root.period(x,"weeks","nbinomial")
 root.period(x,"months","nbinomial") 
 root.period(x,"quarters","nbinomial") # that does not fit nbinomial at all
 root.period(x,"quarters","nbinomial",begin="2010-01-01",end="2010-12-31") # that at least computes something

# third example:
 root.period(x,"days","nbinomial",scale="raw") # values are plotted on the raw scale (y label is Frequency)
 root.period(x,"days","nbinomial") # values are plotted on the square root scale (y label is sqrt(Frequency))

# fourth example:
x<- read.loss(1,2,loss.data.object)
b = "2010-01-01"
e = "2010-12-31"
 root.period(x,"days","nbinomial",begin=b,end=e) # fit via ML (Maximum Likelihood) 
 root.period(x,"days","nbinomial","MinChisq",begin=b,end=e) # fit via Minimum Chi-squared.
 # there are some significant differences in function values table, param and p

# fifth example:
 # some changes of bar colours, lines and points types
 root.period(x,"days","nbinomial",rect_gp =gpar(fill = "lightblue"),
                lines_gp = gpar(col = "black"),points_gp = gpar(col = "darkblue"), pch = 20)

# sixth example:
 root.period(x,"days","nbinomial") # differences in bar types
 root.period(x,"days","nbinomial",bar_type="standing")
 root.period(x,"days","nbinomial",bar_type="deviation")




