### Name: read.loss
### Title: Loss reading
### Aliases: read.loss
### Keywords: ~kwd1 ~kwd2

### ** Examples

data(loss.data.object)

loss.data.object$blines[1] # business line "Agency Services"
loss.data.object$rcateg[2] # risk category "Clients, Products & Business Practices"
x<- read.loss(1,2,loss.data.object) # reads losses (dates and amounts)
head(x)



