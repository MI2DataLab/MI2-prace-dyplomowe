### Name: loss.matrix
### Title: Creates loss matrix
### Aliases: loss.matrix


### ** Examples

data(loss.data.object)
D <- loss.matrix(loss.data.object)
D # see also loss.matrix.image




