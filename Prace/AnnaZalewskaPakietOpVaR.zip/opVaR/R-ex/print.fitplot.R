### Name: print.fitplot
### Title: Printing for "fitplot" class
### Aliases: print.fitplot


### ** Examples

# The function is currently defined as:
# function(x) print(x$ad)



