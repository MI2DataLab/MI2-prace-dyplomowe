### Name: loss.data.object
### Title: Operational risk data
### Aliases: loss.data.object


### ** Examples

data(loss.data.object)
summary(loss.data.object) # a simple summary
str(loss.data.object) # compactly display the internal structure of an loss.data.object (more detailed)

head(loss.data.object$losses)



