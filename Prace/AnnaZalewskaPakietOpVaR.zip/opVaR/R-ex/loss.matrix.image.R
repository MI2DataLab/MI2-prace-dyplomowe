### Name: loss.matrix.image
### Title: Draws loss matrix image
### Aliases: loss.matrix.image


### ** Examples

data(loss.data.object)
D <- loss.matrix(loss.data.object)

# first example:

loss.matrix.image(D,loss.data.object$blines,loss.data.object$rcateg)

# second example:

loss.matrix.image(D,loss.data.object$blines,loss.data.object$rcateg,col1="ghostwhite") # one colour is changed

# third example:

 # not every business and risk line is chosen
loss.matrix.image(D[c(2,8),,c(1,3,5)],loss.data.object$blines[c(2,8)],loss.data.object$rcateg[c(1,3,5)])




