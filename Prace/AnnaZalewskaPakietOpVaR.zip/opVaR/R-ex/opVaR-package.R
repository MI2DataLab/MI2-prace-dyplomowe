### Name: opVaR-package
### Title: Computing operational risk - opVaR package
### Aliases: opVaR-package opVaR
### Keywords: package

### ** Examples

data(loss.data.object)

D<- loss.matrix(loss.data.object);D
        # matrix of loss summaries

loss.matrix.image(data=loss.data.object)
        # table of loss summaries

loss.density(a=1,b=2,loss.data.object)
        # loss denisties for every business line
        # and second risk category
        # "Clients, Products and Business Practices"

x<- read.loss(3,2,loss.data.object)
        # read losses from third business line
        # and second risk category

hist.period(x,"days")
        # frequency histogram for days
root.period(x,"days","nbinomial")
        # fitted frequency - nbinomial

z<- x[,2] # these are losses amounts
par(mfrow = c(1,2))
fit.plot(z,dnorm, param = list(mean = mean(z),sd = sd(z)))
fit.plot(z,dnorm, param = list(mean = mean(z),sd = sd(z)),draw.diff=T)
        # empirical and fitted severity distributions

loss.fit.dist("lognormal",x)
        # fitting lognormal distribution 
        
mc(x,rfun="log-normal",nmb=200)
        # 200 yearly losses simulated for x
        # with given lognormal distribution as severity distribution
        # and chosen binomial distribution as frequency distribution




