### Name: mc
### Title: Monte Carlo loss simulation
### Aliases: mc


### ** Examples

data(loss.data.object)

x<- read.loss(3,2,loss.data.object)

# first example:

 l1 = mc(x,begin="2010-01-01",end="2010-12-31")$table
 l1

# second example:

 l2 = mc(x,rfun = "inverse gaussian",nmb =100)$table
 l2 # yearly losses for 100 years, 365 days per year

# third example:

 l3 = mc(x,rfun = "beta", p=c(0.95))$table

# fourth example:

 l4 = mc(x,rfun = "beta",type = "binomial")$table # type of frequency distribution is chosen

# fifth example:

 l5 = mc(x,rfun = rbeta,param = list(shape1 = 0.47,shape2 = 36.66),period = "days",distname = "beta")$table
# parameters for beta distribution are given

# sixth example:

 l6 = mc(x,rfun = "normal") # comapare loss.fit.dist("normal",x) - fit is very poor

# seventh example:

 l7 = mc(x,rfun = rnorm,type = "binomial",param = list(mean=3,sd=4))$table
# parameters for normal distribution are given (and very poor, comparing loss.fit.dist("normal",x) or sixth example )

# eighth example:

 l8 = mc(x,flist= c("normal","inverse gaussian"))$table




